<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
	<meta charset="UTF-8">
	<link href="./styleex.css" rel="stylesheet">
	<title>نمونه کار</title>
</head>
<body>
	<div class="main">
		<div class="masthead">
			<div class="top_menu">
				<div class="container">
					<div class="Pul_right">
						<ul>
							<li>
								<a href="#">صفحه اصلی</a>
							</li>
							<li>
								<a href="#">درباره ما</a>
							</li>
							<li>
								<a href="#">نمونه کارها</a>
							</li>
							<li>
								<a href="#">تماس با ما</a>
							</li>
						</ul>
					</div>
					<div class="pul_left"></div>
				</div>
			</div>
			<div class="main_menu">
				<div class="container">
					<div class="pul_right">
						<ul>
							<li>
								<a href="#">صفحه اصلی</a>
							</li>
							<li>
								<a href="#">درباره ما</a>
							</li>
							<li>
								<a href="#">نمونه کارها</a>
							</li>
							<li>
								<a href="#">تماس با ما</a>
							</li>
						</ul>
					</div>
					<div class="pul_left">
						<div class="logo">
							<a href="#"><img alt="arx arts logo" src="images/2.png"></a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
		<div id="gallery">
			<div class="gallery">
				<div class="gallery-item">
					<a href="#"><img alt="" src="images/3.jpg"></a>
				</div>
				<div class="gallery-item">
					<a href="#"><img alt="" src="images/4.jpg"></a>
				</div>
				<div class="gallery-item">
					<a href="#"><img alt="" src="images/6.jpg"></a>
				</div>
				<div class="gallery-item">
					<a href="#"><img alt="" src="images/7.jpg"></a>
				</div>
				<div class="clearfix"></div>
				<div class="gallery-item">
					<a href="#"><img alt="" src="images/14.jpg"></a>
				</div>
				<div class="gallery-item">
					<a href="#"><img alt="" src="images/14.jpg"></a>
				</div>
				<div class="gallery-item">
					<a href="#"><img alt="" src="images/9.jpg"></a>
				</div>
				<div class="gallery-item">
					<a href="#"><img alt="" src="images/6.jpg"></a>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
		<div id="team">
			<div class="team">
				<div class="container">
					<div class="area-titel">
						<h2>لورم ایپسوم متن ساختگی</h2>
						<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.</p>
					</div>
					<div class="clearfix">
						<div class="team-details">
							<img alt="" src="profile/1.jpg">
							<div class="team-content">
								<h2>لورم ایپسوم</h2>
								<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.</p>
							</div>
						</div>
						<div class="team-details">
							<img alt="" src="profile/2.jpg">
							<div class="team-content">
								<h2>لورم ایپسوم</h2>
								<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.</p>
							</div>
						</div>
						<div class="team-details">
							<img alt="" src="profile/3.jpg">
							<div class="team-content">
								<h2>لورم ایپسوم</h2>
								<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div id="customer">
			<div class="customer">
				<div class="container">
					<div class="area-titel">
						<h2>لورم ایپسوم متن ساختگی</h2>
						<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.</p>
					</div>
					<div class="clearfix"></div>
					<div class="item">
						<div class="item-text">
							<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.</p>
						</div>
						<div class="item-info">
							<img alt="" src="customer/1.png"> <span class="name">رضا صبوری</span><br>
							<span>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است</span>
						</div>
					</div>
					<div class="item">
						<div class="item-text-active">
							<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.</p>
						</div>
						<div class="item-info">
							<img alt="" src="customer/2.png"> <span class="name">رضا صبوری</span><br>
							<span>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است</span>
						</div>
					</div>
					<div class="item">
						<div class="item-text">
							<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.</p>
						</div>
						<div class="item-info">
							<img alt="" src="customer/3.png"> <span class="name">رضا صبوری</span><br>
							<span>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است</span>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div id="newsletter">
			<div class="nwesletter">
				<div class="overly"></div>
				<div class="container">
					<div class="half">
						<div class=" title-newsletter">عضویت در خبرنامه</div>
					</div>
					<div class="half">
						<form action="">
							<input type="text" placeholder="عضویت در خبرنامه">
							<input type="submit" value="عضویت">
						</form>
					</div>
				</div>
			</div>
		</div>
	
		<div id="blog">
			<div class="blog">
				<div class="container">
					<div class="blog-single">
						<img src="blog/1.png" alt="تصویر شماره یک">
						<div class="blog-item">
							
						<h2><a href="#"> لورم ایپسوم</a></h2>
						<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است </p>
					
						</div>


					</div>
					<div class="blog-single">
						<img src="blog/2.png" alt="تصویر شماره یک">
						<div class="blog-item">
							
						<h2><a href="#"> لورم ایپسوم</a></h2>
						<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است </p>
					
						</div>


					</div>
					<div class="blog-single">
						<img src="blog/1.png" alt="تصویر شماره یک">
						<div class="blog-item">
							
						<h2><a href="#"> لورم ایپسوم</a></h2>
						<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است </p>
					
						</div>


					</div>

				
						
							

						
				</div>
			</div>
		</div>
	<div class="footers">
		نمونه کار شماره یک 
		
		<span><a href="https://t.me/abol1254">طراحی توسط abolfazl bahramnezhad</a></span>
	</div>
	</div>
	
</body>
</html>